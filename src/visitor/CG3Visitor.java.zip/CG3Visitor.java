package visitor;

import syntaxtree.*;

import errorMsg.*;
import java.io.*;

public class CG3Visitor extends ASTvisitor {

	// the purpose here is to annotate things with their offsets:
	// - formal parameters, with respect to the (callee) frame
	// - local variables, with respect to the frame
	// - instance variables, with respect to their slot in the object
	// - methods, with respect to their slot in the v-table
	// - while statements, with respect to the stack-size at the time
	//   of loop-exit
	
	// Error message object
	ErrorMsg errorMsg;
	
	// IO stream to which we will emit code
	CodeStream code;

	// current stack height
	int stackHeight;
	
	// for constant evaluation
	ConstEvalVisitor conEvalVis;
	
	public CG3Visitor(ErrorMsg e, PrintStream out) {
		errorMsg = e;
		initInstanceVars(out);
		conEvalVis = new ConstEvalVisitor();
	}
	
	private void initInstanceVars(PrintStream out) {
		code = new CodeStream(out, errorMsg);
		stackHeight = 0;
	}
	
	public Object visitLocalVarDecl(LocalVarDecl n){
		n.initExp.accept(this);
		n.offset = -stackHeight;
		return null;
	}
	
	public Object visitIntegerLiteral(IntegerLiteral n) {
		stackHeight += 8;
		code.emit(n, "subu $sp, $sp, 8");
		code.emit(n, "sw $s5, 4($sp)");
		code.emit(n, "li $t0, " + n.val);
		code.emit(n, "sw $t0, ($sp)");
		return null;
	}
	
	public Object visitStringLiteral(StringLiteral n) {
		stackHeight += 4;
		code.emit(n, "subu $sp, $sp, 4");
		code.emit(n, "la $t0, strLit_" + n.uniqueId);
		code.emit(n, "sw $t0, ($sp)");
		return null;
	}
	public Object visitPlus(Plus n) {
		n.left.accept(this);
		n.right.accept(this);
		stackHeight -= 8;
		code.emit(n, "lw $t0, ($sp)");
		code.emit(n, "lw $t1, 8($sp)");
		code.emit(n, "addu $t0, $t0, $t1");
		code.emit(n, "addu $sp, $sp, 8");
		code.emit(n, "sw $t0, ($sp)");
		return null;
	}
	
	public Object visitMinus(Minus n) {
		n.left.accept(this);
		n.right.accept(this);
		stackHeight -= 8;
		code.emit(n, "lw $t0, ($sp)");
		code.emit(n, "lw $t1, 8($sp)");
		code.emit(n, "subu $t0, $t1, $t0");
		code.emit(n, "addu $sp, $sp, 8");
		code.emit(n, "sw $t0, ($sp)");
		return null;
	}
	
	public Object visitTimes(Times n) {
		n.left.accept(this);
		n.right.accept(this);
		stackHeight -= 8;
		code.emit(n, "lw $t0, ($sp)");
		code.emit(n, "lw $t1, 8($sp)");
		code.emit(n, "mult $t0, $t1");
		code.emit(n, "mflo $t0");
		code.emit(n, "addu $sp, $sp, 8");
		code.emit(n, "sw $t0, ($sp)");
		return null;
	}	
	
	public Object visitDivide(Divide n) {
		n.left.accept(this);
		n.right.accept(this);
		code.emit(n, "jal divide");
		stackHeight -= 8;
		return null;
	}	
	
	public Object visitThis(This n){
		stackHeight += 4;
		code.emit(n, "subu $sp, $sp, 4");
		code.emit(n, "sw $s2, ($sp)");
		return null;
	}
	
	public Object visitSuper(Super n){
		stackHeight += 4;
		code.emit(n, "subu $sp, $sp, 4");
		code.emit(n, "sw $s2, ($sp)");
		return null;
	}
	
	public Object visitNewObject(NewObject n){
		stackHeight += 4;
		code.emit(n, "subu $sp, $sp, 4");
		code.emit(n, "sw $zero, ($sp)");
		return null;
	}
	
	public Object visitCall(Call n){
		int currentStackHeight = stackHeight;
		n.obj.accept(this);
		n.parms.accept(this);
		if(n.methodLink.pos < 0)
			code.emit(n, "jal " + n.methodLink.name + "_" + n.methodLink.classDecl.name);
		else 
			code.emit(n, "jal fcn_" +  n.methodLink.uniqueId + "_" + n.methodLink.name);

		if(n.type instanceof VoidType)
			stackHeight = currentStackHeight;
		else if(n.type instanceof IntegerType)
			stackHeight = currentStackHeight + 8;
		else 
			stackHeight = currentStackHeight + 4;

		return null;
	}
	
	public Object visitIdentifierExp(IdentifierExp n){
		if(n.link instanceof LocalVarDecl){
			int stackDepth = stackHeight + n.link.offset;
			code.emit(n, "lw $t0, " + stackDepth + "($sp)");
		}
		if(n.type instanceof IntegerType){
			stackHeight += 8;
			code.emit(n, "subu $sp, $sp, 8");
			code.emit(n, "sw $s5, 4($sp)");
			code.emit(n, "sw $t0, ($sp)");
		}
		else{
			stackHeight += 4;
			code.emit(n, "subu $sp, $sp, 4");
			code.emit(n, "sw $t0, ($sp)");
		}
		return null;
	}
	
	public Object visitProgram(Program n) {
		code.emit(n, ".text");
		code.emit(n, ".global main");
		code.emit(n, "main:");
		code.emit(n, "jal vm_init");
		stackHeight = 0;
		n.mainStatement.accept(this);
		code.emit(n, "CLASS_String:");
		code.emit(n, "CLASS_Object:");
		code.emit(n, "li $v0, 10");
		code.emit(n, "syscall");
		n.classDecls.accept(this);
		code.flush();
		return null;
	}
	
	public Object visitMethodDeclVoid(MethodDeclVoid n){
		code.emit(n, ".global fcn_" + n.uniqueId + "_" + n.name);
		code.emit(n, "fcn_" + n.uniqueId + "_" + n.name + ":");
		code.emit(n, "subu $sp, $sp, 4");
		code.emit(n, "sw $s2, ($sp)");
		code.emit(n, "lw $s2, " + n.thisPtrOffset + "($sp)");
		code.emit(n, "sw $ra, " + n.thisPtrOffset + "($sp)");
		stackHeight = 0;
		n.stmts.accept(this);
		int relativeLocation = stackHeight + n.thisPtrOffset;
		code.emit(n, "lw $ra, " + relativeLocation + "($sp)");
		code.emit(n, "lw $s2, " + (relativeLocation + 4) + "($sp)");
		int pop = stackHeight + 8;
		code.emit(n, "addu $sp, $sp, " + pop);
		code.emit(n, "jr $ra");
		return null;
	}

}


	
